package com.musica.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.common.util.UnstableApi
import android.content.ComponentName
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import java.util.Locale

private val Bg = Color(0xFF0D0D0F)
private val Panel = Color(0xFF1A1A1F)
private val Accent = Color(0xFFFF5A36)
private val Muted = Color(0xFF96969F)

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long, val albumId: Long)

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private lateinit var permissionLauncher: ActivityResultLauncher<String>
    private var permissionCallback: ((Boolean) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val controllerState = androidx.compose.runtime.mutableStateOf<MediaController?>(null)
        val token = SessionToken(this, ComponentName(this, MusicPlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({ runCatching { controllerState.value = future.get() } }, mainExecutor)
        }
        permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            permissionCallback?.invoke(granted)
            permissionCallback = null
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onBackground = Color.White, onSurface = Color.White
            )) {
                val connectedPlayer = controllerState.value
                if (connectedPlayer == null) {
                    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Accent)
                    }
                } else {
                    MusicApp(
                        player = connectedPlayer,
                        loadSongs = { readSongs() },
                        hasPermission = { audioPermissionGranted() },
                        requestPermission = { callback -> requestAudioPermission(callback) }
                    )
                }
            }
        }
    }

    private fun audioPermissionGranted(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission(callback: (Boolean) -> Unit) {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        permissionCallback = callback
        permissionLauncher.launch(permission)
    }

    private fun readSongs(): List<Song> {
        val songs = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                songs += Song(
                    id,
                    cursor.getString(titleCol) ?: "Sin título",
                    cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Artista desconocido",
                    ContentUris.withAppendedId(collection, id),
                    cursor.getLong(durationCol),
                    cursor.getLong(albumCol)
                )
            }
        }
        return songs
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun MusicApp(
    player: Player,
    loadSongs: () -> List<Song>,
    hasPermission: () -> Boolean,
    requestPermission: ((Boolean) -> Unit) -> Unit
) {
    var permission by remember { mutableStateOf(hasPermission()) }
    var songs by remember { mutableStateOf(emptyList<Song>()) }
    var selected by remember { mutableStateOf<Song?>(null) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var searchQuery by remember { mutableStateOf("") }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var playlistDialog by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    var savedPlaylists by remember { mutableStateOf<Map<String, List<Long>>>(emptyMap()) }
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("music_playlists", android.content.Context.MODE_PRIVATE)
        val raw = prefs.getString("playlists", "{}") ?: "{}"
        runCatching {
            val json = org.json.JSONObject(raw)
            savedPlaylists = json.keys().asSequence().associateWith { key ->
                val arr = json.getJSONArray(key)
                (0 until arr.length()).map { arr.getLong(it) }
            }
        }
    }
    fun persistPlaylists(value: Map<String, List<Long>>) {
        savedPlaylists = value
        val json = org.json.JSONObject()
        value.forEach { (name, ids) -> json.put(name, org.json.JSONArray(ids)) }
        context.getSharedPreferences("music_playlists", android.content.Context.MODE_PRIVATE)
            .edit().putString("playlists", json.toString()).apply()
    }
    val visibleSongs = remember(songs, searchQuery) {
        if (searchQuery.isBlank()) songs else songs.filter {
            it.title.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    fun refresh() { songs = loadSongs() }

    LaunchedEffect(permission) { if (permission) refresh() }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val index = player.currentMediaItemIndex
                if (index in songs.indices) selected = songs[index]
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.takeIf { it > 0 } ?: (selected?.duration ?: 0L)
            delay(500)
        }
    }

    fun playSong(index: Int) {
        if (index !in songs.indices) return
        selected = songs[index]
        player.setMediaItems(songs.map { song ->
            val artwork = Uri.parse("content://media/external/audio/albumart/${song.albumId}")
            MediaItem.Builder().setUri(song.uri).setMediaMetadata(
                MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).setArtworkUri(artwork).build()
            ).build()
        }, index, 0L)
        player.prepare()
        player.play()
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Accent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("🔥Musica🔥", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text("TU MÚSICA. SIN RUIDO.", fontSize = 10.sp, letterSpacing = 2.sp, color = Muted)
            }
            IconButton(onClick = { if (permission) refresh() else requestPermission { permission = it } }) {
                Icon(Icons.Default.Refresh, "Actualizar biblioteca", tint = Muted)
            }
        }

        if (!permission) {
            Spacer(Modifier.height(50.dp))
            Icon(Icons.Default.LibraryMusic, null, tint = Accent, modifier = Modifier.align(Alignment.CenterHorizontally).size(54.dp))
            Text("Tu música, en un solo lugar", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 18.dp))
            Text("Permite el acceso a los archivos de audio para encontrar tus canciones.",
                color = Muted, modifier = Modifier.padding(horizontal = 36.dp, vertical = 12.dp))
            Button(onClick = { requestPermission { granted -> permission = granted } },
                modifier = Modifier.align(Alignment.CenterHorizontally), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Text("Dar permiso")
            }
        } else {
            Row(Modifier.padding(horizontal = 22.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("BIBLIOTECA", color = Color.White, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("${visibleSongs.size} canciones", color = Muted, fontSize = 12.sp)
                IconButton(onClick = { playlistDialog = true }) {
                    Icon(Icons.Default.QueueMusic, contentDescription = "Listas de reproducción", tint = Accent)
                }
            }
            OutlinedTextField(
                value = searchQuery, onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp),
                placeholder = { Text("Buscar canción o artista", color = Muted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Buscar", tint = Muted) },
                trailingIcon = { if (searchQuery.isNotEmpty()) IconButton(onClick = { searchQuery = "" }) { Icon(Icons.Default.Close, "Borrar búsqueda") } },
                singleLine = true, shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedBorderColor = Accent, unfocusedBorderColor = Panel,
                    cursorColor = Accent, focusedContainerColor = Panel, unfocusedContainerColor = Panel
                )
            )
            if (songs.isEmpty()) {
                Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.MusicOff, null, tint = Muted, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Todavía no hay canciones", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Añade archivos de audio a tu teléfono.", color = Muted, fontSize = 13.sp)
                }
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                    itemsIndexed(visibleSongs, key = { _, song -> song.id }) { _, song ->
                        val index = songs.indexOfFirst { it.id == song.id }
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(if (selected?.id == song.id) Panel else Color.Transparent)
                                .clickable { playSong(index) }.padding(horizontal = 10.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (selected?.id == song.id) Accent.copy(alpha = .18f) else Panel),
                                contentAlignment = Alignment.Center) {
                                AlbumArtwork(song = song, modifier = Modifier.fillMaxSize())
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(song.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Text(formatTime(song.duration), color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                if (visibleSongs.isEmpty() && songs.isNotEmpty()) {
                    Text("No se encontraron canciones", color = Muted, modifier = Modifier.padding(24.dp))
                }
            }

            if (playlistDialog) {
                AlertDialog(
                    onDismissRequest = { playlistDialog = false },
                    title = { Text("Listas de reproducción") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = playlistName, onValueChange = { playlistName = it },
                                label = { Text("Nombre de la lista") }, singleLine = true)
                            Text("Crear una lista guarda las canciones de la biblioteca actual.", fontSize = 12.sp, color = Muted)
                            savedPlaylists.keys.forEach { name ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(name, modifier = Modifier.weight(1f), color = Color.White)
                                    TextButton(onClick = {
                                        val ids = savedPlaylists[name].orEmpty()
                                        val queue = ids.mapNotNull { id -> songs.find { it.id == id } }
                                        if (queue.isNotEmpty()) {
                                            selected = queue.first()
                                            player.setMediaItems(queue.map { song ->
                                                MediaItem.Builder().setUri(song.uri).setMediaMetadata(
                                                    MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist)
                                                        .setArtworkUri(Uri.parse("content://media/external/audio/albumart/${song.albumId}")).build()
                                                ).build()
                                            }, 0, 0L)
                                            player.prepare(); player.play()
                                        }
                                    }) { Text("Reproducir") }
                                    IconButton(onClick = { persistPlaylists(savedPlaylists - name) }) {
                                        Icon(Icons.Default.Delete, "Eliminar lista", tint = Muted)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = {
                        val name = playlistName.trim()
                        if (name.isNotEmpty() && songs.isNotEmpty()) {
                            persistPlaylists(savedPlaylists + (name to songs.map { it.id }))
                            playlistName = ""
                        }
                        playlistDialog = false
                    }) { Text("Guardar") } },
                    dismissButton = { TextButton(onClick = { playlistDialog = false }) { Text("Cerrar") } }
                )
            }
            selected?.let { song ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(24.dp)).background(Panel).padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(Accent.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
                            AlbumArtwork(song = song, modifier = Modifier.fillMaxSize())
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(song.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Slider(
                        value = position.toFloat().coerceIn(0f, (duration.takeIf { it > 0 } ?: 1L).toFloat()),
                        onValueChange = { position = it.toLong() },
                        onValueChangeFinished = { player.seekTo(position) },
                        valueRange = 0f..(duration.takeIf { it > 0 } ?: 1L).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatTime(position), color = Muted, fontSize = 11.sp)
                        Text(formatTime(duration), color = Muted, fontSize = 11.sp)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = {
                            shuffleEnabled = !shuffleEnabled
                            player.shuffleModeEnabled = shuffleEnabled
                        }) {
                            Icon(Icons.Default.Shuffle, "Aleatorio", tint = if (shuffleEnabled) Accent else Muted)
                            Spacer(Modifier.width(4.dp))
                            Text("Aleatorio", color = if (shuffleEnabled) Accent else Muted, fontSize = 12.sp)
                        }
                        TextButton(onClick = {
                            repeatMode = when (repeatMode) {
                                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                else -> Player.REPEAT_MODE_OFF
                            }
                            player.repeatMode = repeatMode
                        }) {
                            Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                                "Repetición", tint = if (repeatMode != Player.REPEAT_MODE_OFF) Accent else Muted)
                            Spacer(Modifier.width(4.dp))
                            Text(when (repeatMode) { Player.REPEAT_MODE_ALL -> "Repetir todo"; Player.REPEAT_MODE_ONE -> "Repetir una"; else -> "Sin repetir" },
                                color = if (repeatMode != Player.REPEAT_MODE_OFF) Accent else Muted, fontSize = 12.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else playSong((songs.indexOf(selected) - 1 + songs.size) % songs.size) }) {
                            Icon(Icons.Default.SkipPrevious, "Anterior", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        Spacer(Modifier.width(20.dp))
                        IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() },
                            modifier = Modifier.size(64.dp).clip(CircleShape).background(Accent)) {
                            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pausar" else "Reproducir",
                                tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                        Spacer(Modifier.width(20.dp))
                        IconButton(onClick = { if (player.hasNextMediaItem()) player.seekToNextMediaItem() else playSong((songs.indexOf(selected) + 1) % songs.size) }) {
                            Icon(Icons.Default.SkipNext, "Siguiente", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                    }
                }
            } ?: Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun AlbumArtwork(song: Song, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, song.albumId) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val uri = Uri.parse("content://media/external/audio/albumart/${song.albumId}")
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
            }.getOrNull()
        }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!, contentDescription = "Carátula de ${song.title}", modifier = modifier,
            contentScale = ContentScale.Crop)
    } else {
        Box(modifier.background(Accent.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Album, contentDescription = "Sin carátula", tint = Accent, modifier = Modifier.size(28.dp))
        }
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000).toInt()
    return String.format(Locale.getDefault(), "%d:%02d", total / 60, total % 60)
}
